exports.constants = {
  VALIDATION_ERROR: 400,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  SERVER_ERROR: 500,
  FIELDS: "windSpeed,temperature,humidity,rainIntensity",
  API_KEY:"8QjbCGX9sOP5AGGCDHx9FUbXKdKo1bA2",
  API_KEY2:"LWaqHbzjJjj1yVnjKUT0h8Pti2wRBSt1",
  HEADERS: ("Content-Type", "application/json")
};
